from django.apps import AppConfig


class CorecodeConfig(AppConfig):
    name = 'corecode'
