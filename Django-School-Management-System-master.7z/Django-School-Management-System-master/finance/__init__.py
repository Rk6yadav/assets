default_app_config = 'finance.apps.FinanceConfig'
