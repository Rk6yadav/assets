from django.apps import AppConfig


class RtempConfig(AppConfig):
    name = 'rtemp'
