from django.urls import path
from . import views
urlpatterns = [
    # path('',views.year_archive,name='year_archive')
]
